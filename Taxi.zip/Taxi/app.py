from flask import Flask, render_template, request
import joblib
import os

app = Flask(__name__)

# Load the trained model
model_path = os.path.join(os.path.dirname(__file__), 'taxi_model.pkl')
model = joblib.load(model_path)

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    try:
        # Get values from form
        population = float(request.form['population'])
        income = float(request.form['income'])
        parking = float(request.form['parking'])
        riders = float(request.form['riders'])

        # Predict using the model
        prediction = model.predict([[population, income, parking, riders]])[0]

        # Render result template with prediction
        return render_template('result.html',
                               population=population,
                               income=income,
                               parking=parking,
                               riders=riders,
                               prediction=round(prediction, 2))
    except Exception as e:
        return f"Error: {e}"

if __name__ == '__main__':
    app.run(debug=True)
